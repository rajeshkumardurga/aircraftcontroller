package com.aircraft.app.AirCraftManagementApp;

public class AirCraftStatus {

	public static final String LANDING = "LANDING_CONFIRMED"; 
	public static final String WAITING = "WAITING"; 

}
